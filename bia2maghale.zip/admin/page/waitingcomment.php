<?php
include '../../database/db.php';
if($_SESSION['role'] < 4 ){
    header('location:../../error/index.html');
}
include'../../js/jdf.php';
$number=1;
$butcolor=null;
$all = $conn->prepare("SELECT * FROM comments WHERE status=?");
$all->bindValue(1 , 0);
$all->execute();
$comments = $all->fetchAll(PDO::FETCH_ASSOC);
if ($all->rowCount()>=1) {
$butcolor=true;
}else{
    $butcolor=false;


}
?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <link rel="stylesheet" href="../../css/style.css">

    <title>Admin</title>
</head>

<body>
    <div class="container">
        

        <br><br>

        <a class="btn btn-success" href="comments.php">بازگشت به کامنت ها منتشر شده</a>

<br><br>


        <div class="row" style="padding: 30px;">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">نظر</th>
                        <th scope="col">نظردهنده</th>
                        <th scope="col">تاریخ انتشار</th>
                        <th scope="col">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($comments as $comment){ ?>
                        <tr>
                        <th scope="row"><?php echo $number++;  ?></th>
                        <td class="comment-text"><?php echo $comment['text'];  ?></td>
                        <td><?php echo $comment['userid'];  ?></td>
                        <td><?php echo jdate('Y/m/d', $comment['date'])?></td>
                        <td>
                            
                        <a href="comments.php?id=<?php echo $comment['id']; ?>" class="btn btn-warning">انتشار</a>
                            <a href="deletecomment.php?id=<?php echo $comment['id']; ?>" class="btn btn-danger">حذف</a>
                            
                        </td>

                    </tr>


                        <?php  } ?>



                  


                </tbody>
            </table>

        </div>
    </div>
</body>
<script src="../../js/jquery-3.5.1.min.js"></script>
<script src="../../js/bootstrap.min.js"></script>

</html>