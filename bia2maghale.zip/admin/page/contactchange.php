<?php
include '../../database/db.php';
if($_SESSION['role'] < 5 ){
    header('location:../../error/index.html');
}

if (isset($_POST['sub'])) {
    $contact=$_POST['contact'];


 
    $result = $conn->prepare("UPDATE contact SET contact=?");
    $result->bindValue(1, $contact);
    $result->execute(); 
}
$all = $conn->prepare("SELECT * FROM contact");
$all->execute();
$contactthings = $all->fetch(PDO::FETCH_ASSOC);
$contactth = $contactthings['contact'];


?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <link rel="stylesheet" href="../../css/style.css">
    <script src="../../ckeditor/ckeditor.js"></script>

    <title>Admin</title>
    <style>
        input , textarea{
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
<div class="container">
        <div class="row">
            <ul class="nav nav-pills nav-fill">
                <li class="nav-item">
                    <a class="nav-link" href="menu.php">منو</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="manageusers.php">مدیریت کاربران</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="blog.php">وبلاگ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="writers.php">نویسندگان</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="comments.php">کامنت های سایت</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="contactchange.php">ویرایش صفحه ارتباط با ما</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="../../" style="color: firebrick;">بازگشت به صفحه اصلی سایت</a>
                </li>
            </ul>
        </div>
        <br><br>
        <div class="row">
            <form method="POST">
                <textarea name="contact" id="editor1"><?= $contactth?></textarea>
            <script>
                CKEDITOR.replace( 'editor1' );
            </script>
          
            <br>
            <input type="submit" name="sub" class="btn btn-primary" value="ویرایش">

                
            </form>
        </div><br>
       
</body>
<script src="../../js/jquery-3.5.1.min.js"></script>
<script src="../../js/bootstrap.min.js"></script>

</html>