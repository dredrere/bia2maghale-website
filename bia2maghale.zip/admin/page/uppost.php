<?php  
include '../../database/db.php';

if(isset($_GET['id'])){
    $i=$_GET['id'];
    $update= $conn->prepare("UPDATE post SET status=? WHERE id=? ");
    $update->bindValue(1 , 1 );
    $update->bindValue(2 , $i );
    $update->execute();

    header("location:waitingpost.php");
    
    }

    ?>