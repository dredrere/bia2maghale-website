<?php
include '../../database/db.php';
if($_SESSION['role'] < 4 ){
    header('location:../../error/index.html');
}
$id = $_GET['id'];

if (isset($_POST['sub'])) {
    $title = $_POST['title'];
    $image = $_POST['image'];
    $content = $_POST['content'];
    $tag = $_POST['tag'];
    $writer = $_POST['writer'];
    $time = time();
 
    $result = $conn->prepare("UPDATE post SET title=? , image=? , content=? , tag=? , writer=? , date=? WHERE id=?");
    $result->bindValue(1, $title);
    $result->bindValue(2, $image);
    $result->bindValue(3, $content);
    $result->bindValue(4, $tag);
    $result->bindValue(5, $writer);
    $result->bindValue(6, $time);
    $result->bindValue(7, $id);
    $result->execute(); 


$all = $conn->prepare("SELECT * FROM writers");
$all->execute();
$writers = $all->fetchAll(PDO::FETCH_ASSOC);

$all = $conn->prepare("SELECT * FROM post WHERE id=?");
$all->bindValue(1, $id);
$all->execute();
$post = $all->fetch(PDO::FETCH_ASSOC);
}

$all = $conn->prepare("SELECT * FROM writers");
$all->execute();
$writers = $all->fetchAll(PDO::FETCH_ASSOC);

$all = $conn->prepare("SELECT * FROM post WHERE id=?");
$all->bindValue(1, $id);
$all->execute();
$post = $all->fetch(PDO::FETCH_ASSOC);
?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <link rel="stylesheet" href="../../css/style.css">
    <script src="../../ckeditor/ckeditor.js"></script>

    <title>Admin</title>
    <style>
        input,
        textarea {
            margin-bottom: 15px;
        }
    </style>
</head>

<body>
    <div class="container">
        <br><br><br>
        <div class="row">
            <form method="POST">
                <input type="text" name="title" class="form-control" placeholder="عنوان" value="<?php echo $post['title'];   ?>">
                <input type="text" name="image" class="form-control" placeholder="تصویر" value="<?php echo $post['image'];   ?>">
                <textarea name="content" id="editor1" placeholder="متن را وارد کنید"><?php echo $post['content'];   ?></textarea>
                <script>
                    CKEDITOR.replace('editor1');
                </script>
                <input type="text" name="tag" class="form-control" placeholder="برچسب ها" value="<?php echo $post['tag'];   ?>">
                <select name="writer" class="form-control">
                    <?php foreach ($writers as $writer) : ?>
                        <option value="<?php echo $writer['id'];  ?>"<?php if($post['writer']==$writer['id']){  ?>selected<?php }?>><?php echo $writer['name'];?></option>


                    <?php endforeach; ?>

                </select>
                <br>
                <input type="submit" name="sub" class="btn btn-primary" value="ویرایش">
                <a href="blog.php" class="btn btn-danger">بازگشت</a>


            </form>
        </div>
    </div>
</body>
<script src="../../js/jquery-3.5.1.min.js"></script>
<script src="../../js/bootstrap.min.js"></script>

</html>