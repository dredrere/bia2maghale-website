<?php 
include '../../database/db.php';
if($_SESSION['role'] < 5 ){
    header('location:../../error/index.html');
}
$id=$_GET['id'];
$all = $conn->prepare("SELECT * FROM user WHERE id=?");
$all->bindValue(1 ,$id);
$all->execute();
$user = $all->fetch(PDO::FETCH_ASSOC);

if (isset($_POST['sub'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $rd = $_POST['select'];
    $result = $conn->prepare("UPDATE user SET username=? , email=? , role=?  WHERE id=?");
    $result->bindValue(1, $username);
    $result->bindValue(2, $email);
    $result->bindValue(3, $rd);
    $result->bindValue(4, $id);
    $result->execute();
    header('location:manageusers.php');
}


?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <link rel="stylesheet" href="../../css/style.css">

    <title>Admin</title>
</head>

<body>
    <div class="container">
        <div class="row" style="padding: 30px;">
            <form method="post"><br><br>
                <input name="username" type="text" placeholder="نام کاربری" class="form-control" value="<?php echo $user['username']; ?>"><br>
                <input name="email" type="email" placeholder=" ایمیل کاربر" class="form-control" value="<?php echo $user['email']; ?>"><br>
                <br>


                <select name="select" class="form-select" aria-label="Default select example">
  <option <?php if($user['role']==1){ ?> selected<?php }?> value="1"> کاربر عادی</option>
  <option <?php if($user['role']==2){ ?> selected<?php }?> value="2">داور</option>
  <option <?php if($user['role']==3){ ?> selected<?php }?> value="3">نویسنده</option>
  <option <?php if($user['role']==4){ ?> selected<?php }?> value="4">سردبیر</option>
  <option <?php if($user['role']==5){ ?> selected<?php }?> value="5">مدیر</option>
</select><br><br>



                <input type="submit" value="ثبت" name="sub" class="btn btn-primary">
                <a href="manageusers.php" class="btn btn-danger">بازگشت</a>

            </form><br><br>
            

        </div>
    </div>
</body>
<script src="../../js/jquery-3.5.1.min.js"></script>
<script src="../../js/bootstrap.min.js"></script>

</html>