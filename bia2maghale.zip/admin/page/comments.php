<?php
include '../../database/db.php';
if($_SESSION['role'] < 4 ){
    header('location:../../error/index.html');
}
include'../../js/jdf.php';
if(isset($_GET['id'])){
    $i=$_GET['id'];
    $update= $conn->prepare("UPDATE comments SET status=? WHERE id=? ");
    $update->bindValue(1 , 1 );
    $update->bindValue(2 , $i );
    $update->execute();

    header("location:waitingcomment.php");
    
    }
    
$number=1;
$all = $conn->prepare("SELECT * FROM comments WHERE status=? ORDER BY date DESC");
$all->bindValue(1 , 1);
$all->execute();
$comments = $all->fetchAll(PDO::FETCH_ASSOC);

$ball = $conn->prepare("SELECT * FROM comments WHERE status=?");
$ball->bindValue(1 , 0);
$ball->execute();
if ($ball->rowCount()>=1) {
$butcolor=true;
}else{
    $butcolor=false;


}

?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <link rel="stylesheet" href="../../css/style.css">

    <title>Admin</title>
</head>

<body>
    <div class="container">
        <div class="row">
            <ul class="nav nav-pills nav-fill">
                <li class="nav-item">
                    <a class="nav-link" href="menu.php">منو</a>
                </li>
                <?php  if($_SESSION['role']==5){  ?>
                <li class="nav-item">
                    <a class="nav-link" href="manageusers.php">مدیریت کاربران</a>
                </li><?php } ?>
                <li class="nav-item">
                    <a class="nav-link" href="blog.php">وبلاگ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="writers.php">نویسندگان</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="comments.php">کامنت های سایت</a>
                </li>
                <?php  if($_SESSION['role']==5){  ?>
                <li class="nav-item">
                    <a class="nav-link" href="contactchange.php">ویرایش صفحه ارتباط با ما</a>
                </li><?php } ?>
                <li class="nav-item">
                <a class="nav-link" href="../../" style="color: firebrick;">بازگشت به صفحه اصلی سایت</a>
                </li>
            </ul>
        </div>
<br><br>


        <a class="<?php if($butcolor==true){  ?>btn btn-warning<?php }else{ ?> lol<?php } ?>" href="waitingcomment.php"><?php if($butcolor==true){ ?> کامنت های جدید منتشر نشده<?php }?></a>

<br><br>

        <div class="row" style="padding: 30px;">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">نظر</th>
                        <th scope="col">نظردهنده</th>
                        <th scope="col">تاریخ انتشار</th>
                        <th scope="col">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($comments as $comment){ ?>
                        <tr>
                        <th scope="row"><?php echo $number++;  ?></th>
                        <td class="comment-text"><?php echo $comment['text'];  ?></td>
                        <td><?php echo $comment['userid'];  ?></td>
                        <td><?php echo jdate('Y/m/d', $comment['date'])?></td>
                        <td>
                            <a href="deletecomment.php?id=<?php echo $comment['id']; ?>" class="btn btn-danger">حذف</a>
                        </td>
                    </tr>


                        <?php  } ?>



                  


                </tbody>
            </table>

        </div>
    </div>
</body>
<script src="../../js/jquery-3.5.1.min.js"></script>
<script src="../../js/bootstrap.min.js"></script>

</html>