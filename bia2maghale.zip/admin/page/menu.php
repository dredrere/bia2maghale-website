<?php
include '../../database/db.php';
if($_SESSION['role'] < 4 ){
    header('location:../../error/index.html');
}
$number=1;
if (isset($_POST['sub'])) {
    $title = $_POST['title'];
    $sort = $_POST['sort'];
    $rd = $_POST['rd'];
    $link=$_POST['link'];
    $result = $conn->prepare("INSERT INTO menu SET title=? , sort=? , status=? , link=?");
    $result->bindValue(1, $title);
    $result->bindValue(2, $sort);
    $result->bindValue(3, $rd);
    $result->bindValue(4, $link);
    $result->execute();
}
$all = $conn->prepare("SELECT * FROM menu");
$all->execute();
$menus = $all->fetchAll(PDO::FETCH_ASSOC);

?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <link rel="stylesheet" href="../../css/style.css">

    <title>Admin</title>
</head>

<body>
    <div class="container">
        <div class="row">
            <ul class="nav nav-pills nav-fill">
                <li class="nav-item">
                    <a class="nav-link active" href="menu.php">منو</a>
                </li>
                <?php  if($_SESSION['role']==5){  ?>
                <li class="nav-item">
                    <a class="nav-link" href="manageusers.php">مدیریت کاربران</a>
                </li><?php } ?>
                <li class="nav-item">
                    <a class="nav-link" href="blog.php">وبلاگ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="writers.php">نویسندگان</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="comments.php">کامنت های سایت</a>
                </li>
                <?php  if($_SESSION['role']==5){  ?>
                <li class="nav-item">
                    <a class="nav-link" href="contactchange.php">ویرایش صفحه ارتباط با ما</a>
                </li><?php } ?>
                <li class="nav-item">
                <a class="nav-link" href="../../" style="color: firebrick;">بازگشت به صفحه اصلی سایت</a>
                </li>
            </ul>
        </div>
        <div class="row" style="padding: 30px;">
            <form method="post"><br><br>
                <input name="title" type="text" placeholder="عنوان" class="form-control"><br>
                <input name="sort" type="number" placeholder="اولویت بندی" class="form-control"><br>
                <input name="link" type="text" placeholder="لینک منو" class="form-control"><br>
                <div class="custom-control custom-radio">
                    <input type="radio" value="1" id="customRadio1" name="rd" class="custom-control-input" checked>
                    <label class="custom-control-label" for="customRadio1">فعال</label>
                </div>
                <div class="custom-control custom-radio">
                    <input type="radio" value="0" id="customRadio2" name="rd" class="custom-control-input">
                    <label class="custom-control-label" for="customRadio2">غیر فعال</label>
                </div><br>
                <input type="submit" value="ثبت" name="sub" class="btn btn-primary">

            </form><br><br>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">عنوان</th>
                        <th scope="col">اولویت بندی</th>
                        <th scope="col">وضعیت</th>
                        <th scope="col">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($menus as $menu){ ?>
                        <tr>
                        <th scope="row"><?php echo $number++;  ?></th>
                        <td><?php echo $menu['title'];  ?></td>
                        <td><?php echo $menu['sort'];  ?></td>
                        <td><?php if($menu['status'] == 1) { ?><span class="btn btn-success" style="font-size: 12px;">فعال</span><?php  }else{?><span class="btn btn-dark" style="font-size: 12px;">غیر فعال</span><?php }?></td>
                        <td>
                            <a href="editmenu.php?id=<?php echo $menu['id']; ?>" class="btn btn-warning">ویرایش</a>
                            <a href="deletemenu.php?id=<?php echo $menu['id']; ?>" class="btn btn-danger">حذف</a>
                        </td>
                    </tr>


                        <?php  } ?>



                  


                </tbody>
            </table>

        </div>
    </div>
</body>
<script src="../../js/jquery-3.5.1.min.js"></script>
<script src="../../js/bootstrap.min.js"></script>

</html>