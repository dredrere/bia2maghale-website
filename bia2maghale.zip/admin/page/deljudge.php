<?php

include '../../database/db.php';
if(isset($_GET['cmid'])){
    $cmid=$_GET['cmid'];
    $result = $conn->prepare("DELETE FROM judge WHERE id=?");
  $result->bindValue(1,$cmid);
  $result->execute();
  header("location:javascript://history.go(-1)");
  
  }

?>