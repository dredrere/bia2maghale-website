<?php
include '../../database/db.php';
if($_SESSION['role'] < 4 ){
    header('location:../../error/index.html');
}
include'../../js/jdf.php';
$id=$_GET['id'];
$number=1;

$all = $conn->prepare("SELECT * FROM writers");
$all->execute();
$writers = $all->fetchAll(PDO::FETCH_ASSOC);

$all = $conn->prepare("SELECT * FROM post WHERE writer=? ORDER BY date DESC");
$all->bindValue(1 , $id );
$all->execute();
$posts = $all->fetchAll(PDO::FETCH_ASSOC);


?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <link rel="stylesheet" href="../../css/style.css">
    <script src="../../ckeditor/ckeditor.js"></script>

    <title>Admin</title>
</head>
<body>
<div class="container">
        <a class="btn btn-info" href="writers.php">بازگشت</a>
<div class="row">
        <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">عنوان</th>
                        <th scope="col">تصویر</th>
                        <th scope="col">نویسنده</th>
                        <th scope="col">تاریخ</th>
                        <th scope="col">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($posts as $post){ ?>
                        <tr>
                        <th scope="row"><?php echo $number++;  ?></th>
                        <td><?php echo $post['title']; ?></td>
                        <td><img src="<?php echo $post['image']; ?>" height="80px" width="135px" alt=""></td>
                        <td><?php foreach($writers as $writer){if ($post['writer']== $writer['id']){echo $writer['name'];}}  ?></td>
                        <td><?php echo jdate('Y/m/d' , $post['date']); ?></td>
                        <td>
                            <a href="editpost.php?id=<?php echo $post['id']; ?>" class="btn btn-warning">ویرایش</a>
                            <a href="deletepost.php?id=<?php echo $post['id']; ?>" class="btn btn-danger">حذف</a>
                        </td>
                  
                    </tr>


                        <?php  } ?>
                </tbody>
            </table>
        </div>
        </div>
</body>
<script src="../../js/jquery-3.5.1.min.js"></script>
<script src="../../js/bootstrap.min.js"></script>

</html>
