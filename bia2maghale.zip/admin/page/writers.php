<?php
include '../../database/db.php';
if($_SESSION['role'] < 4 ){
    header('location:../../error/index.html');
}

$number=1;
if (isset($_POST['sub'])) {
    $name = $_POST['name'];
    $result = $conn->prepare("INSERT INTO writers SET name=?");
    $result->bindValue(1, $name);
    
    $result->execute();
    header('location:writers.php');
} 
$all = $conn->prepare("SELECT * FROM writers");
$all->execute();
$writers = $all->fetchAll(PDO::FETCH_ASSOC);

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <link rel="stylesheet" href="../../css/style.css">

    <title>Admin</title>
</head>
<body>
<div class="container">
        <div class="row">
            <ul class="nav nav-pills nav-fill">
                <li class="nav-item">
                    <a class="nav-link" href="menu.php">منو</a>
                </li>
                <?php  if($_SESSION['role']==5){  ?>
                <li class="nav-item">
                    <a class="nav-link" href="manageusers.php">مدیریت کاربران</a>
                </li><?php } ?>
                <li class="nav-item">
                    <a class="nav-link" href="blog.php">وبلاگ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="writers.php">نویسندگان</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="comments.php">کامنت های سایت</a>
                </li>
                <?php  if($_SESSION['role']==5){  ?>
                <li class="nav-item">
                    <a class="nav-link" href="contactchange.php">ویرایش صفحه ارتباط با ما</a>
                </li><?php } ?>
                <li class="nav-item">
                <a class="nav-link" href="../../" style="color: firebrick;">بازگشت به صفحه اصلی سایت</a>
                </li>
            </ul>
        </div>
        <div class="row">
        <form method="post"><br><br>
                <input name="name" type="text" placeholder="نام و نام خانوادگی" class="form-control"><br>
                <input type="submit" value="ثبت" name="sub" class="btn btn-primary">

            </form><br><br>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">نویسنده</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($writers as $writer){ ?>
                        <tr>
                        <th scope="row"><?php echo $number++;  ?></th>
                        <td><?php echo $writer['name'];  ?></td>
                        
                        
                        <td>
                        
                            <a href="deletewriter.php?id=<?php echo $writer['id']; ?>" class="btn btn-danger">حذف</a>
                        </td>
                        <td>
                        
                            <a href="writerpost.php?id=<?php echo $writer['id']; ?>" class="btn btn-warning">مشاهده مقالات این نویسنده</a>
                        </td>
                    </tr>


                        <?php  } ?>


        </div>
</body>
<script src="../../js/jquery-3.5.1.min.js"></script>
<script src="../../js/bootstrap.min.js"></script>

</html>