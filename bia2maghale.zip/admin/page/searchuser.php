<?php
include '../../database/db.php';
if($_SESSION['role'] < 5 ){
    header('location:../../error/index.html');
}
    $email=$_GET['email'];
$all = $conn->prepare("SELECT * FROM user WHERE email=?");
$all->bindValue(1, $email);
$all->execute();
$users = $all->fetchAll(PDO::FETCH_ASSOC);
if(isset($_POST['search'])){
    $search = $_POST['usersearch'];
    header("location:searchuser.php?email=$search");

}



?>



<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <link rel="stylesheet" href="../../css/style.css">

    <title>Admin</title>
</head>
<body>
<div class="container">
        <div class="row">
            <ul class="nav nav-pills nav-fill">
                <li class="nav-item">
                    <a class="nav-link" href="menu.php">منو</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="manageusers.php">مدیریت کاربران</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="blog.php">وبلاگ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="writers.php">نویسندگان</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="comments.php">کامنت های سایت</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contactchange.php">ویرایش صفحه ارتباط با ما</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="../../" style="color: firebrick;">بازگشت به صفحه اصلی سایت</a>
                </li>
            </ul>
        </div>
        <div class="row">
        <form method="post"><br><br>
                <input name="usersearch" type="email" placeholder="جستجوی کاربر با ایمیل" class="form-control"><br>
                <input type="submit" value="جستجو" name="search" class="btn btn-primary">

            </form><br><br>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">id</th>
                        <th scope="col">کاربر</th>
                        <th scope="col">ایمیل کاربر</th>
                        <th scope="col">سطح کاربر</th>
                        <th scope="col">عملیات </th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach($users as $user){ ?>
                        <tr>
                        <th scope="row"><?php echo $user['id'];  ?></th>
                        <td><?php echo $user['username'];  ?></td>
                        <td><?php echo $user['email'];  ?></td>
                        <td><?php if($user['role']==1){ ?>کاربر عادی<?php } ?><?php if($user['role']==5){ ?> ادمین<?php } ?><?php if($user['role']==4){ ?> سردبیر<?php } ?><?php if($user['role']==3){ ?> نویسنده<?php } ?><?php if($user['role']==2){ ?> داور<?php } ?></td>

                        
                        
                        <td>
                        <a href="changerole.php?id=<?php echo $user['id']; ?>" class="btn btn-warning">ویرایش سطح کاربر</a>
                            <a href="deleteuser.php?id=<?php echo $user['id']; ?>" class="btn btn-danger">حذف کاربر</a>
                        </td>
                    </tr>


                        <?php  } ?>


        </div>
</body>
<script src="../../js/jquery-3.5.1.min.js"></script>
<script src="../../js/bootstrap.min.js"></script>

</html>