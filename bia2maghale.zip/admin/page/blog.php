<?php
include '../../database/db.php';
if($_SESSION['role'] < 3 ){
    header('location:../../error/index.html');
}
$number=1;
include'../../js/jdf.php';
if (isset($_POST['sub'])) {
    $title = $_POST['title'];
    $image = $_POST['image'];
    $content = $_POST['content'];
    $tag = $_POST['tag'];
    $writer = $_POST['writer'];
    $time = time();
 
    $result = $conn->prepare("INSERT INTO post SET title=? , image=? , content=? , tag=? , writer=? , date=?");
    $result->bindValue(1, $title);
    $result->bindValue(2, $image);
    $result->bindValue(3, $content);
    $result->bindValue(4, $tag);
    $result->bindValue(5, $writer);
    $result->bindValue(6, $time);
    $result->execute(); 
}



$all = $conn->prepare("SELECT * FROM writers");
$all->execute();
$writers = $all->fetchAll(PDO::FETCH_ASSOC);

$all = $conn->prepare("SELECT * FROM post WHERE status=1 ORDER BY date DESC");
$all->execute();
$posts = $all->fetchAll(PDO::FETCH_ASSOC);




?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <link rel="stylesheet" href="../../css/style.css">
    <script src="../../ckeditor/ckeditor.js"></script>

    <title>Admin</title>
    <style>
        input , textarea{
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
<div class="container">
        <div class="row">
            <ul class="nav nav-pills nav-fill">
            <?php  if($_SESSION['role'] > 3){  ?>
                <li class="nav-item">
                    <a class="nav-link" href="menu.php">منو</a>
                </li><?php } ?>
                <?php  if($_SESSION['role']==5){  ?>
                <li class="nav-item">
                    <a class="nav-link" href="manageusers.php">مدیریت کاربران</a>
                </li><?php } ?>
                <li class="nav-item">
                    <a class="nav-link active" href="blog.php">وبلاگ</a>
                </li>
                <?php  if($_SESSION['role'] > 3){  ?>
                <li class="nav-item">
                    <a class="nav-link" href="writers.php">نویسندگان</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="comments.php">کامنت های سایت</a>
                </li><?php } ?>
                <?php  if($_SESSION['role']==5){  ?>
                <li class="nav-item">
                    <a class="nav-link" href="contactchange.php">ویرایش صفحه ارتباط با ما</a>
                </li><?php } ?>
                <li class="nav-item">
                <a class="nav-link" href="../../" style="color: firebrick;">بازگشت به صفحه اصلی سایت</a>
                </li>
            </ul>
        </div>
        <br><br>
        <div class="row">
            <form method="POST">
                <input type="text" name="title" class="form-control" placeholder="عنوان">
                <input type="text" name="image" class="form-control" placeholder="تصویر">
                <textarea name="content" id="editor1">&lt;p&gt;متن را وارد کنید.&lt;/p&gt;</textarea>
            <script>
                CKEDITOR.replace( 'editor1' );
            </script>
            <input type="text" name="tag" class="form-control" placeholder="برچسب ها">
            <select name="writer" class="form-control">
                <?php foreach($writers as $writer) : ?>
                    <option value="<?php echo $writer['id'];  ?>"><?php echo $writer['name'];  ?></option>


                    <?php endforeach; ?>

            </select>
            <br>
            <input type="submit" name="sub" class="btn btn-primary" value="ثبت">

                
            </form>
           
        
        </div><br>
        <?php  $check = $conn->prepare('SELECT * FROM post WHERE status=0');
    $check->execute();
    if ($check->rowCount()>=1) { ?>
        
            <a class="btn btn-warning" href="waitingpost.php"> مشاهده مقالات در انتظار انتشار </a>
                <?php  }?><br><br>


        <div class="row">
        <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">عنوان</th>
                        <th scope="col">تصویر</th>
                        <th scope="col">نویسنده</th>
                        <th scope="col">تعداد بازدید</th>
                        <th scope="col">تاریخ</th>
                        <th scope="col">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($posts as $post){
                        $idpost = $post['id'];

                        $result = $conn->prepare("SELECT COUNT(id) FROM view WHERE post=?");
                        $result->bindValue(1, $idpost);
                        $result->execute();
                        $numviews = $result->fetch(PDO::FETCH_ASSOC);
                        foreach ($numviews as $numview) {
                        } ?>
                        <tr>
                        <th scope="row"><?php echo $number++;  ?></th>
                        <td><?php echo $post['title']; ?></td>
                        <td><img src="<?php echo $post['image']; ?>" height="80px" width="135px" alt=""></td>
                        <td><?php foreach($writers as $writer){if ($post['writer']== $writer['id']){echo $writer['name'];}}  ?></td>
                        <td><?php echo $numview ?></td>
                        <td><?php echo jdate('Y/m/d' , $post['date']); ?></td>
                        <?php if($_SESSION['role']>3){ ?>
                        <td>
                            <a href="editpost.php?id=<?php echo $post['id']; ?>" class="btn btn-warning">ویرایش</a>
                            <a href="deletepost.php?id=<?php echo $post['id']; ?>" class="btn btn-danger">حذف</a>
                        </td>
                        <?php  } ?>
                  
                    </tr>


                        <?php  } ?>
                </tbody>
            </table>
        </div>
</body>
<script src="../../js/jquery-3.5.1.min.js"></script>
<script src="../../js/bootstrap.min.js"></script>

</html>