<?php
include '../../database/db.php';
if($_SESSION['role'] < 2 ){
    header('location:../../error/index.html');
}
include'../../js/jdf.php';

$postid=$_GET['id'];



if (isset($_POST['sub'])) {
    $text = $_POST['comment'];
    $userid = $_SESSION['id'];
    
    $time = time();
    $comments = $conn->prepare("INSERT INTO judge SET text=? , postid=? , userid=?  , date=?");
    $comments->bindValue(1, $text);
    $comments->bindValue(2, $postid);
    $comments->bindValue(3, $userid);
    $comments->bindValue(4, $time);
    $comments->execute();
}

$showcomments = $conn->prepare("SELECT * FROM judge WHERE postid=? ORDER BY date DESC");
$showcomments->bindValue(1, $postid);
$showcomments->execute();
$showcomments = $showcomments->fetchAll(PDO::FETCH_ASSOC);


?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../../css/bootstrap.css">
    <link rel="stylesheet" href="../../css/style.css">
    <script src="../../ckeditor/ckeditor.js"></script>

    <title>Admin</title>
</head>
<body>
    <div class="container">
        <a class="btn btn-info" href="waitingpost.php">بازگشت</a>
<div class="row">
<div> <br>
                    <b>نظرات داوران</b>
                    <?php if ($_SESSION['role'] == 2 ) {  ?>

                        <form method="POST"><br>
                            <textarea name="comment" id="editor1">&lt;p&gt;پیام خود را وارد کنید.&lt;/p&gt;</textarea>
                            <script>
                                CKEDITOR.replace('editor1');
                            </script>
                            <br>
                            <input name="sub" type="submit" value="ثبت دیدگاه" class="btn btn-success">
                        </form>
                    <?php  } else { ?>
                        <h6 style="margin-top: 10px; color:#28a745; margin-bottom:10px;">فقط داور میتواند نظر دهد!        ! </h6>
                    <?php  } ?>
                </div> <br><br>


                <div class="comments"><br><br><br><br><br><br>
                    <?php foreach ($showcomments as $cm) { ?>
                        <div class="comment-item">
                            <div class="comment-image">
                                <img src="../../images/blankprofilepic.jpg" width="100px" alt="">
                            </div>
                            <div class="comment-text">
                                <span class="username-comment"><?= $cm['userid'] ?> </span>
                                <span>ارسال شده در <?php echo jdate('d F Y', $cm['date']); ?></span>
                                <?php if (isset($_SESSION['login'])) {  ?>
                                    <?php if ($cm['userid'] == $_SESSION['id']) {  ?>

                                        <a href="deljudge.php?cmid=<?= $cm['id'] ?>" class="btn btn-danger" style="margin-right: 5px;"> حذف این نظر</a>

                                <?php }
                                } ?>

                                <?= $cm['text']; ?>
                            </div>
                        </div>
                    <?php } ?>



                </div>




        
        </div>
        </div>
</body>
<script src="../../js/jquery-3.5.1.min.js"></script>
<script src="../../js/bootstrap.min.js"></script>

</html>