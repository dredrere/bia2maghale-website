<?php
include '../database/db.php';
if($_SESSION['role'] < 3 ){
    header('location:../error/index.html');
}

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">

    <title>Admin</title>
</head>
<body>
<div class="container">
        <div class="row">
            <ul class="nav nav-pills nav-fill">
                <li class="nav-item">
                    <a class="nav-link" href="page/menu.php">منو</a>
                </li>
                <?php  if($_SESSION['role']==5){  ?>
                <li class="nav-item">
                    <a class="nav-link" href="page/manageusers.php">مدیریت کاربران</a>
                </li><?php } ?>
                <li class="nav-item">
                    <a class="nav-link" href="page/blog.php">وبلاگ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="page/writers.php">نویسندگان</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="page/comments.php">کامنت های سایت</a>
                </li>
                <?php  if($_SESSION['role']==5){  ?>
                <li class="nav-item">
                    <a class="nav-link" href="page/contactchange.php">ویرایش صفحه ارتباط با ما</a>
                </li><?php } ?>
                <li class="nav-item">
                <a class="nav-link" href="../" style="color: firebrick;">بازگشت به صفحه اصلی سایت</a>
                </li>
            </ul>
        </div>
</body>
<script src="../js/jquery-3.5.1.min.js"></script>
<script src="../js/bootstrap.min.js"></script>

</html>