<?php
include 'database/db.php';
include 'js/jdf.php';

if(isset($_POST['search'])){
    $search = $_POST['searchcontent'];
    header("location:pages/search.php?post=$search");

}

$result = $conn->prepare("SELECT COUNT(id) FROM post");
$result->execute();
$numposts = $result->fetch(PDO::FETCH_ASSOC);
foreach ($numposts as $numpost) {
}


$result = $conn->prepare("SELECT COUNT(id) FROM writers");
$result->execute();
$numwriters = $result->fetch(PDO::FETCH_ASSOC);
foreach ($numwriters as $numwriter) {
}

$result = $conn->prepare("SELECT COUNT(id) FROM user");
$result->execute();
$numusers = $result->fetch(PDO::FETCH_ASSOC);
foreach ($numusers as $numuser) {
}

$menus = $conn->prepare("SELECT * FROM menu ORDER BY sort");
$menus->execute();
$menus = $menus->fetchAll(PDO::FETCH_ASSOC);



$writers = $conn->prepare("SELECT * FROM writers");
$writers->execute();
$writers = $writers->fetchAll(PDO::FETCH_ASSOC);

function limit_words($string, $word_limit)
{
    $words = explode(" ", $string);
    return implode(" ", array_splice($words, 0, $word_limit));
}
$numperpage = 9;
$page = isset($_GET["start"]) ? $_GET["start"] : 0;

if (!$page) $page = 0;
$start = $page * $numperpage;

$result = $conn->prepare("SELECT COUNT(id) FROM post WHERE status=1;");
$result->execute();
$row = $result->fetch();
$numrecords = $row[0];

$numlinks = ceil($numrecords / $numperpage);

$posts = $conn->prepare("SELECT * FROM post WHERE status=1 ORDER BY date DESC LIMIT $start,$numperpage");
$posts->execute();
$posts = $posts->fetchAll(PDO::FETCH_ASSOC);



?>
<html lang="fa">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">

    <title>بیا تو مقاله</title>
    <link rel="icon" type="image" href="images/logo2.png" />
</head>

<body>
    <div class="container">
        <br>
        <!---menu start--->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <img class="logo" src="images/logo2.png">
            <a class="navbar-brand" style="color: #28a745;" href="#">بیا تو مقاله</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav">
                    <li class="nav-item active">
                        <a class="nav-link" style="color: limegreen;" href="#">خانه</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                         دسته بندی ها
                        </a>
                        <div class="dropdown-menu dropdown-menu-left" aria-labelledby="navbarDropdown">
                            <?php foreach ($menus as $menu) {
                                if ($menu['status'] == 1) {  ?>

                                    <a class="nav-link" href="<?php echo $menu['link'];  ?>"><?php echo $menu['title'];  ?></a>

                            <?php }
                            } ?>
                        </div>
                    </li>




                    <?php if (isset($_SESSION['login'])) {  ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                حساب کاربری
                            </a>
                            <div class="dropdown-menu dropdown-menu-left" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="#">نام شما:<?php echo  $_SESSION['usernameo']  ?> </a>
                                <a class="dropdown-item" href="#">ایمیل شما:<?php echo $_SESSION['email']  ?> </a>
                                <a class="dropdown-item" href="#">سطح دسترسی: <?php  if($_SESSION['role']==1){ ?>کاربر عادی<?php } ?><?php if($_SESSION['role']==5){ ?> ادمین<?php } ?><?php if($_SESSION['role']==4){ ?> سردبیر<?php } ?><?php if($_SESSION['role']==3){ ?> نویسنده<?php } ?><?php if($_SESSION['role']==2){ ?> داور<?php }  ?> </a>
                                <a class="dropdown-item" href="pages/changeinfo.php"> ویرایش حساب کاربری</a>
                                <?php if ($_SESSION['role'] == 2) { ?><a class="dropdown-item" href="admin/page/waitingpost.php">رای و نظر به مقالات منتشر نشده </a><?php } ?>
                                <?php if ($_SESSION['role'] > 2) { ?><a class="dropdown-item" href="admin/page/blog.php">نوشتن مقاله</a><?php } ?>
                                <?php if ($_SESSION['role'] > 3) { ?><a class="dropdown-item" href="admin/index.php">پنل مدیریت</a><?php } ?>
                                <a class="nav-link rozial" href="pages/log.php" style="color: firebrick;">خروج</a>
                            </div>
                        </li>


                    <?php  } else { ?>
                        <li class="nav-item">
                            <a class="nav-link" href="pages/login.php">ورود</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="pages/register.php">ثبت نام</a>
                        </li>
                    <?php } ?>


                    <li class="nav-item">
                        <a class="nav-link" href="pages/contact.php">تماس با ما</a>
                    </li>
                </ul>
                <form method="POST" class="form-inline my-2 my-lg-0 mr-auto">
                    <input class="form-control mr-sm-2 placholder" type="search" placeholder="دنبال چی میگردی؟" aria-label="Search" name="searchcontent">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit" style="font-size: 15px;" name="search">جستجو</button>
                </form>
            </div>
        </nav>
        <!---menu end--->
        <!---start content--->
        <br>
        <div>
            <div class="row d-none d-lg-flex">
                <div class="col-4 information-site">
                    <img src="images/stat-time.svg" alt="">
                    <span>تعداد مقالات:</span>
                    <span><?php echo $numpost; ?></span>
                </div>
                <div class="col-4 information-site">
                    <img src="images/stat-teacher.svg" alt="">

                    <span>نویسندگان ما:</span>
                    <span><?php echo $numwriter; ?></span>
                </div>
                <div class="col-4 information-site">
                    <img src="images/stat-student.svg" alt="">
                    <span>تعداد کاربران:</span>
                    <span><?php echo $numuser; ?></span>
                </div>
            </div>
        </div>

        <!---end content--->
        <!---start post--->
        <br class="d-none d-lg-flex"><br class="d-none d-lg-flex">
        <div>
            <h5 style="padding: 10px;">مقالات وبلاگ</h4>
                <div class="row">
                    <?php foreach ($posts as $post) {
                        $idpost = $post['id'];

                        $result = $conn->prepare("SELECT COUNT(id) FROM view WHERE post=?");
                        $result->bindValue(1, $idpost);
                        $result->execute();
                        $numviews = $result->fetch(PDO::FETCH_ASSOC);
                        foreach ($numviews as $numview) {
                        }
                        $result = $conn->prepare("SELECT COUNT(id) FROM comments WHERE postid=?");
                        $result->bindValue(1, $idpost);
                        $result->execute();
                        $numcoms = $result->fetch(PDO::FETCH_ASSOC);
                        foreach ($numcoms as $numcom) {
                        }
                    ?>
                        <div class="col-12 col-lg-4">
                            <div class="post-item">
                                <a href="pages/single.php?post=<?php echo $post['title']; ?>" class="item-hover-btn"><img src="<?php echo $post['image']; ?>" alt="" height="250px" width="100%">
                                    <div class="hovershow">
                                        <div class="hover-image-post d-none d-lg-flex">
                                        </div>
                                        <a href="pages/single.php?post=<?php echo $post['title']; ?>" class="more-post btn d-none d-lg-flex">مشاهده مقاله</a>
                                    </div>
                                </a>

                                <div class="post-caption">
                                    <p><a href="pages/single.php?post=<?php echo $post['title']; ?>"><?php echo $post['title'];  ?></a></p>
                                    <span><?php echo limit_words($post['content'], 13) . ' ...';; ?></span>
                                    <br><br>
                                    <span class="seen-post">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-fill" viewBox="0 0 16 16">
                                            <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z" />
                                            <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8zm8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z" />
                                        </svg><?= $numview ?>
                                        <span class="seen-post post-comment">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chat-square-fill" viewBox="0 0 16 16">
                                                <path d="M2 0a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2.5a1 1 0 0 1 .8.4l1.9 2.533a1 1 0 0 0 1.6 0l1.9-2.533a1 1 0 0 1 .8-.4H14a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2z" />
                                            </svg><?= $numcom ?>
                                        </span>
                                        <span class="float-left post-m">
                                            <a href=""> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
                                                    <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" />
                                                </svg><?php foreach ($writers as $writer) {
                                                            if ($post['writer'] == $writer['id']) {
                                                                echo $writer['name'];
                                                            }
                                                        } ?>






                                            </a>
                                        </span>
                                </div>

                            </div>

                        </div>
                    <?php  } ?>

                </div>


        </div>

        <nav aria-label="Page navigation">

            <ul class="pagination pagi">
                <li class="page-item"><a class="page-link" href="index.php?start=<?php if ($page > 0) {
                                                                                        $b = $page - 1;
                                                                                        echo $b;
                                                                                    }  ?>">صفحه قبل</a></li>
                <?php for ($i = 0; $i < $numlinks; $i++) {
                    $y = $i + 1; ?>
                    <li class="page-item"><a class="page-link" href="index.php?start=<?php echo $i ?>"><?php echo $y; ?></a></li>
                <?php } ?>
                <li class="page-item"><a class="page-link" href="index.php?start=<?php $c = $page + 1;
                                                                                    echo $c;  ?>">صفحه بعد</a></li>
            </ul>

        </nav>




    </div>



    <br><br><br><br><br><br>
    <!--website footer -->
    <footer>
        <div class="footer1">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-7"><br><br><br>
                        <form class="d-none d-lg-block" method="post" action="mailto:abolghasemi35@gmail.com.com">
                        
                            <input type="submit" class="btn btn-success" value="ایمیلی به ما بفرستید! ">
                            
                        </form>
                        
                    </div>
                    <div class="col-12 col-lg-7 bt"><br><br><br>
                        <form class="d-none d-lg-block" method="post" action="pages/contact.php">
                        
                            <input type="submit" class="btn btn-success" value="راه های ارتباطی">
                            
                        </form>
                        
                    </div>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope-fill xp" viewBox="0 0 16 16">
  <path d="M.05 3.555A2 2 0 0 1 2 2h12a2 2 0 0 1 1.95 1.555L8 8.414.05 3.555ZM0 4.697v7.104l5.803-3.558L0 4.697ZM6.761 8.83l-6.57 4.027A2 2 0 0 0 2 14h12a2 2 0 0 0 1.808-1.144l-6.57-4.027L8 9.586l-1.239-.757Zm3.436-.586L16 11.801V4.697l-5.803 3.546Z"/>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone-fill xb" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M1.885.511a1.745 1.745 0 0 1 2.61.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z"/>
</svg>
                    <div class="col-12 col-lg-5">
                        <div class="namad d-none d-lg-block">
                            <img src="images/namad.jpg" height="166px" alt="">
                            <img src="images/namad 2.jpg" height="166px" alt="">

                        </div>
                        <div class="namad2 d-lg-none">
                            <img src="images/namad.jpg" height="166px" alt="">
                            <img src="images/namad 2.jpg" height="166px" alt="">
                        </div>

                    </div>
                    <div class="d-none d-lg-block" style="margin-top: -108px; margin-right: 1100px;">
                        <span style="color: floralwhite;">تاریخ:<?php echo jdate('Y/m/d'); ?></span>
                        <span style="color: floralwhite;"> صفحه :<?php echo $page + 1;  ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer2">تمامی مقالات توسط سردبیر وبسایت تایید شده اند</div>
    </footer>

</body>
<script src="js/jquery-3.5.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>

</html>