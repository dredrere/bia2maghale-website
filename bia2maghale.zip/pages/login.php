<?php
include'../database/db.php';
include '../js/jdf.php';
$successmassage = null;
if (isset($_POST['sub'])) {
    $email=$_POST['email'];
    $password=$_POST['password'];
    $result = $conn->prepare('SELECT * FROM user WHERE email=? AND password=?');
    $result->bindValue(1 ,$email);
    $result->bindValue(2 ,$password);
    $result->execute();
    if ($result->rowCount()>=1) {
        $rows=$result->fetch(PDO::FETCH_ASSOC);
        $_SESSION['login']=true;
        $_SESSION['email']=$email;
        $_SESSION['password']=$password;
        $_SESSION['id']=$rows['id'];
        $_SESSION['usernameo']=$rows['username'];
        $_SESSION['age']=$rows['age'];
        $_SESSION['role']=$rows['role'];
        if (isset($_POST['rem'])) {
            setcookie('email',$_SESSION['email'],time()+60*60*24*7,'/');
            setcookie('password',$_SESSION['password'],time()+60*60*24*7,'/');
        }
        

        header('location:../');
    }else{
        $successmassage = true;

    }



}
$menus = $conn->prepare("SELECT * FROM menu ORDER BY sort");
$menus->execute();
$menus = $menus->fetchAll(PDO::FETCH_ASSOC);
?>
<html lang="fa">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>ورود</title>
</head>

<body>
    <div class="container">
        <br>
        <!---menu start--->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <img class="logo" src="../images/logo2.png">
            <a class="navbar-brand" style="color: #28a745;" href="../index.php">بیا تو مقاله</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav">
                    <li class="nav-item active">
                        <a class="nav-link" href="../index.php">خانه</a>
                    </li>
                    <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                         دسته بندی ها
                        </a>
                        <div class="dropdown-menu dropdown-menu-left" aria-labelledby="navbarDropdown">
                            <?php foreach ($menus as $menu) {
                                if ($menu['status'] == 1) {  ?>

                                    <a class="nav-link" href="<?php echo $menu['link'];  ?>"><?php echo $menu['title'];  ?></a>

                            <?php }
                            } ?>
                        </div>
                    </li>




                    <?php if (isset($_SESSION['login'])) {  ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                حساب کاربری
                            </a>
                            <div class="dropdown-menu dropdown-menu-left" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="#">نام شما:<?php echo  $_SESSION['usernameo']  ?> </a>
                                <a class="dropdown-item" href="#">ایمیل شما:<?php echo $_SESSION['email']  ?> </a>
                                <a class="dropdown-item" href="#">سطح دسترسی: <?php  if($_SESSION['role']==1){ ?>کاربر عادی<?php } ?><?php if($_SESSION['role']==5){ ?> ادمین<?php } ?><?php if($_SESSION['role']==4){ ?> سردبیر<?php } ?><?php if($_SESSION['role']==3){ ?> نویسنده<?php } ?><?php if($_SESSION['role']==2){ ?> داور<?php }  ?> </a>
                                <a class="dropdown-item" href="changeinfo.php"> ویرایش حساب کاربری</a>
                                <?php if ($_SESSION['role'] == 2) { ?><a class="dropdown-item" href="../admin/page/waitingpost.php">رای و نظر به مقالات منتشر نشده </a><?php } ?>
                                <?php if ($_SESSION['role'] > 2) { ?><a class="dropdown-item" href="../admin/page/blog.php">نوشتن مقاله</a><?php } ?>
                                <?php if ($_SESSION['role'] > 3) { ?><a class="dropdown-item" href="../admin/index.php">پنل مدیریت</a><?php } ?>
                                <a class="nav-link rozial" href="log.php" style="color: firebrick;">خروج</a>
                            </div>
                        </li>


                    <?php  } else { ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">ورود</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="register.php">ثبت نام</a>
                        </li>
                    <?php } ?>


                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">تماس با ما</a>
                    </li>
                </ul>
                <form method="POST" class="form-inline my-2 my-lg-0 mr-auto">
                    <input class="form-control mr-sm-2 placholder" type="search" placeholder="دنبال چی میگردی؟" aria-label="Search" name="searchcontent">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit" style="font-size: 15px;" name="search">جستجو</button>
                </form>
            </div>
        </nav>
    </div>
        <!---menu end--->
<br><br><br><br><br><br>
     <div class="container">
         <div class="row">
             <div class="col-lg-4"></div>
             <div class="col-12 col-lg-4">
                 <form method="POST" class="register-form">
                     
                     <input type="email" name="email" placeholder="ایمیل">
                
                     <input type="password" name="password" placeholder="کلمه عبور">
                     <input type="checkbox" name="rem" class="remember-me"><span class="remember-lable">مرا به خاطر بسپار</span>
                     
                     <br>
                     <input type="submit" name="sub" value="ورود" class="btn btn-primary submit-register" style="background-color: #007bff;">
                 </form>
             </div>
             <div class="col-lg-4"></div>
         </div>
     </div>

     <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

    <!--website footer -->
    <footer>
        <div class="footer1">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-7"><br><br><br>
                        <form class="d-none d-lg-block" method="post" action="mailto:abolghasemi35@gmail.com.com">
                        
                            <input type="submit" class="btn btn-success" value="ایمیلی به ما بفرستید! ">
                            
                        </form>
                        
                    </div>
                    <div class="col-12 col-lg-7 bt"><br><br><br>
                        <form class="d-none d-lg-block" method="post" action="contact.php">
                        
                            <input type="submit" class="btn btn-success" value="راه های ارتباطی">
                            
                        </form>
                        
                    </div>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope-fill xp" viewBox="0 0 16 16">
  <path d="M.05 3.555A2 2 0 0 1 2 2h12a2 2 0 0 1 1.95 1.555L8 8.414.05 3.555ZM0 4.697v7.104l5.803-3.558L0 4.697ZM6.761 8.83l-6.57 4.027A2 2 0 0 0 2 14h12a2 2 0 0 0 1.808-1.144l-6.57-4.027L8 9.586l-1.239-.757Zm3.436-.586L16 11.801V4.697l-5.803 3.546Z"/>
</svg>
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone-fill xb" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M1.885.511a1.745 1.745 0 0 1 2.61.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z"/>
</svg>
                    <div class="col-12 col-lg-5">
                        <div class="namad d-none d-lg-block">
                            <img src="../images/namad.jpg" height="166px" alt="">
                            <img src="../images/namad 2.jpg" height="166px" alt="">

                        </div>
                        <div class="namad2 d-lg-none">
                            <img src="../images/namad.jpg" height="166px" alt="">
                            <img src="../images/namad 2.jpg" height="166px" alt="">
                        </div>

                    </div>
                    <div class="d-none d-lg-block" style="margin-top: -108px; margin-right: 1100px;">
                        <span style="color: floralwhite;">تاریخ:<?php echo jdate('Y/m/d'); ?></span>
                       
                    </div>
                </div>
            </div>
        </div>
        <div class="footer2">تمامی مقالات توسط سردبیر وبسایت تایید شده اند</div>
    </footer>

</body>
<?php if($successmassage==true){  ?>
    <script>
        const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.addEventListener('mouseenter', Swal.stopTimer)
    toast.addEventListener('mouseleave', Swal.resumeTimer)
  }
})

Toast.fire({
  icon: 'warning',
  title: 'ایمیل یا رمز عبور اشتباه است'
})
    </script>
    <?php  } ?>
<script src="../js/jquery-3.5.1.min.js"></script>
<script src="../js/bootstrap.min.js"></script>

</html>